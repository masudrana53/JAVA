export class FormModel{
id:number=0;
name:string='';
gender:string='';
email:string='';
subject:string='';
address:string='';

}