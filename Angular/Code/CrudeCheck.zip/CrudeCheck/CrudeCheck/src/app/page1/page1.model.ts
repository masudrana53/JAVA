export class PageModel{
id: number=0;
productName: string='';
brand: string='';
price: string='';



}