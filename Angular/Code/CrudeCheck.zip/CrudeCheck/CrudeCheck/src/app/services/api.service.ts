import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService  {
baseUrl: string="http://localhost:3000/student";
  constructor(private http: HttpClient) { }

  save(data:any){
    return this.http.post(this.baseUrl,data).pipe(map((res=>{
      return res;
    })))

  }


  getAll(data:any){
    return this.http.post(this.baseUrl,data).pipe(map((res=>{
      return res;
    })))

  }






}
